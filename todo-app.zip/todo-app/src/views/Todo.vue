<template>
  <div class="container">
    <h1 class="text-center mt-5">To-do App</h1>

    <div class="d-flex justify-content-center">
      <input
        v-model="task"
        type="text"
        placeholder="Enter Task"
        class="form-control"
      />
      <button @click="submitTask" class="btn btn-success rounded-0">ADD</button>
    </div>

    <table class="table table-striped table-dark table-bordered mt-5">
      <thead>
        <tr>
          <th scope="col">หัวข้องาน/การบ้าน</th>
          <th scope="col">สถานะงาน</th>
          <th scope="col">แก้ไขหัวข้องาน/การบ้าน</th>
          <th scope="col">ลบงาน/การบ้าน</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(task, index) in tasks" :key="index">
          <td>
            <span :class="{ finished: task.status === 'ทำเสร็จแล้ว' }">{{
              task.name
            }}</span>
          </td>
          <td style="width: 120px">
            <span
              @click="changeStatus(index)"
              class="pointer"
              :class="{
                'text-danger': task.status === 'ยังไม่ทำ',
                'text-warning': task.status === 'กำลังทำ',
                'text-success': task.status === 'ทำเสร็จแล้ว',
              }"
            >
              {{ firstCharUpper(task.status) }}
            </span>
          </td>
          <td>
            <div class="text-center" @click="editTask(index)">
              <button
                type="button"
                class="btn btn-info btn-sm"
                @click="deletestudent(index)"
              >
                <span class="fa fa-pen"></span>
              </button>
            </div>
          </td>
          <td>
            <div class="text-center" @click="deleteTask(index)">
              <button
                type="button"
                class="btn btn-danger btn-sm"
                @click="deletestudent(index)"
              >
                <span class="fa fa-trash"></span>
              </button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      task: "",
      editedTask: null,
      availableStatuses: ["ยังไม่ทำ", "กำลังทำ", "ทำเสร็จแล้ว"],
      tasks: [
        {
          name: "SE ออกแบบ",
          status: "ทำเสร็จแล้ว",
        },
        {
          name: "Web ออกแบบ UI",
          status: "กำลังทำ",
        },
        {
          name: "Web Assignment 1000",
          status: "ยังไม่ทำ",
        },
      ],
    };
  },

  methods: {
    submitTask() {
      if (this.task.length === 0) return;

      if (this.editedTask === null) {
        this.tasks.push({
          name: this.task,
          status: "ยังไม่ทำ",
        });
      } else {
        this.tasks[this.editedTask].name = this.task;
        this.editedTask = null;
      }

      this.task = "";
    },

    deleteTask(index) {
      this.tasks.splice(index, 1);
    },
    changeStatus(index) {
      let newIndex = this.availableStatuses.indexOf(this.tasks[index].status);
      if (++newIndex > 2) newIndex = 0;
      this.tasks[index].status = this.availableStatuses[newIndex];
    },
    firstCharUpper(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    },
  },
};
</script>

<style>
.pointer {
  cursor: pointer;
}
.finished {
  text-decoration: line-through;
}
</style>
