<template>
  <div>
    <h1>CSMJU</h1>
    <button @click="returnButton">OK</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      n: 0,
    };
  },
  methods: {
    returnButton() {
      this.n++;
      console.log("n @MYButton=" + this.n);
      this.$emit("rtb", 12345, this.n);
    },
  },
};
</script>

<style></style>
